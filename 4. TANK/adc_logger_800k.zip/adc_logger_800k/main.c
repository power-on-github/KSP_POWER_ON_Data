/*
 * adc logger.c
 *
 * Created: 2018-06-19 오후 3:09:31
 * Author : LEFT
 */ 

#define F_CPU 8000000UL
#include <avr/io.h>
#include <stdint.h>
#include <util/delay.h>
#include "pata_UART.h"

void init();

uint8_t channel[2];
uint8_t tmp = 0x00;


int main(void)
{
	UART_init(BAUD_115k, TXRX);
    init();
	
	
    while (1) 
    {
	
		// ADC 1
		ADMUX = (1 << REFS0) | (1 << ADLAR) | 1;
		ADCSRA = (1 << ADEN) | (1 << ADSC) | (6 << ADPS0);
		while (ADCSRA & (1 << ADSC));
		channel[0] = ADCH;
		
		// ADC 2
		ADMUX = (1 << REFS0) | (1 << ADLAR) | 2;
		ADCSRA = (1 << ADEN) | (1 << ADSC) | (6 << ADPS0);
		while (ADCSRA & (1 << ADSC));
		channel[1] = ADCH;
		
		
		// Transmit data
		UART_NWL();
		UART_NWL();
		UART_tx_m(channel, 2);
		
		_delay_ms(100);
		
    }
}

void init()
{
	// Pin IO init
	DDRC = 0;			// PC0~PC5 ADC input
	DDRD = 0x02;		// UART comm
	DDRB = 0x07;		// switch input
	
}