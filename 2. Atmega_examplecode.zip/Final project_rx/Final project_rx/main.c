/*
 * Final project_rx.c
 *
 * Created: 2018-05-04 오후 12:55:53
 * Author : pata
 */ 

#define F_CPU 8000000UL
#include <avr/io.h>

#define RX_BUS		0x02
#define LED			0x01

void init();
void rx_check();

int main(void)
{
    init();
	
    while (1)
    {
		if (PINB & RX_BUS)
		{
			PORTB = LED;
		}
		else
		{
			PORTB = 0;
		}
    }
}

void init()
{
	DDRB = LED;
}