/*
 * PWM.c
 *
 * Created: 2018-03-19 오후 3:46:33
 * Author : right
 */ 

#define F_CPU 8000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdint.h>
#include <util/delay.h>


int main(void)
{
    // IO setting
    DDRB = 0x02;

    // PWM setting (fast pwm mode)
    TCCR1A = (1 << WGM11) | (1 << COM1A1);	// OC1A non-inverting mode
    TCCR1B = (3 << WGM12) | (1 << CS11);	// prescalar: 8
    ICR1 = 9999;

    while (1) 
    {
		for (uint8_t i = 0; i < 10; i++)
		{
			OCR1A = (ICR1 / 10 * i);
			_delay_ms(50);
		}
    }
}
