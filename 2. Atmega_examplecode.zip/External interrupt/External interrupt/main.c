/*
 * External interrupt.c
 *
 * Created: 2018-03-07 오후 2:38:46
 * Author : pata
 */ 

#define F_CPU 8000000UL
#include <avr/io.h>
#include <avr/interrupt.h>

#define ON	1
#define OFF	0

volatile uint8_t toggle = OFF;

void init();

ISR (INT0_vect)
{
	if (toggle == OFF)
		toggle = ON;
	else
		toggle = OFF;
}

int main(void)
{
    init();
	
    while (1) 
    {
		if (toggle == ON)
		{
			PORTB = 1;
		}
		else
		{
			PORTB = 0;
		}
		
    }
}

void init()
{
	DDRB = 0xFF;
	DDRD = 0x00;
	
	MCUCR = (1 << ISC00) | (1 << ISC01);	// INT0핀의 rising edge에 인터럽트가 걸림
}