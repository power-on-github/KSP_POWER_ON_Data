/*
 * Timer.cpp
 *
 * Created: 2018-03-06 오후 9:39:08
 * Author : right
 */ 

#define F_CPU 8000000UL
#include <avr/io.h>
#include <avr/interrupt.h>   // Interrupt를 사용하기 위한 헤더파일.
#include <stdint.h>         // standard 변수형을 사용하기 위한 헤더파일. 필수는 아니나 호환성 등의 이유로 사용한다.

/* 전역변수 */
/* 프밍 수업과는 달리 MCU는 전역변수를 사용하는 것이 속편하다. */
volatile uint8_t timer = 0;      // volatile은 최적화를 막는 명령어이다. 최적화란 변수가 레지스터 영역에 저장되는 것으로 속도를 빠르게
volatile uint8_t temp = 0;      // 하지만 인터럽트에서는 정상 작동을 보장하지 않는다. 따라서 인터럽트에 들어가는 변수는 무조건 
                        // volatile형 변수로 선언해야한다.
						
void init();

/* 인터럽트 함수 */
/* 특정 조건이 만족되면 루틴을 무시하고 이 함수로 들어온다. */
ISR (TIMER0_OVF_vect)
{
   TCNT0 = 5;      // 타이머0을 활성화시키는 값이 저장되는 레지스터. 물양동이 비교하면 이해가 편함.
               // 여기에 값을 넣어주면서 인터럽트가 걸리는데 걸리는 시간을 조절할 수 있음.
   
   temp++;      // 인터럽트가 0.008초 (8ms)에 한번 작동되므로 1초를 만들기 위해서 변수 하나를 만든다.
   
   if (temp > 125)
   {
      timer++;   // 임시 변수가 125가 되면 타이머 변수를 1 늘려준다.
      temp = 0;   // 임시 변수 초기화
   }
   
   if (timer > 3)   // 타이머 최기화
      timer = 0;
}

int main(void)
{
    init();
   sei();

    while (1) 
    {
      switch (timer)         // LED를 키는 부분. Siwtch case문을 공부하도록
      {
         case 0:
            PORTB = 0x00;
            break;
         case 1:
            PORTB = 0x01;
            break;
         case 2:
            PORTB = 0x02;
            break;
         case 3:
            PORTB = 0x04;
            break;
      }
    }
}

void init()
{
   // IO pin 설정
   DDRB = 0xFF;

   // Interrupt 설정
   TCCR0 = (1 << CS02);   // Prescalar를 관리하는 레지스터인 TCCR0의 두번쨰 비트에 1을 넣는다. (비트연산)
   TIMSK = (1 << TOIE0);   // start interrupt
//   TCCR0 = 0b00000010;      // 따라서 이것도 가능함. 다만 가독성이 나쁘므로 보통 데이터 시트를 보면서 정의된 문자를 사용
   
}