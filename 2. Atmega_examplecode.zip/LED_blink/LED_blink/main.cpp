/*
 * LED_blink.cpp
 *
 * Created: 2018-03-06 오후 9:18:20
 * Author : right
 */ 

/*				헤더 파일					*/
/* 특정 기능을 이용하기 위해 이에				*/
/* 대한 정보를 미리 컴파일러에게 알려주는		*/
/* 부분										*/
#define F_CPU 8000000UL		// MCU의 clock 속도를 알려주는 부분. (delay 함수에 필요)
#include <avr/io.h>
#include <util/delay.h>		// delay 함수를 이용하기 위한 헤더 파일
#define LED	0x01
	
/*				함수 선언					*/
/* 코드를 이쁘게 하기 위해 사용자 지정 함수		*/
/* 는 main문 아래 작성한다. (개인 취향)		*/
/* 컴파일러에게 이를 알려주기 위해 선언을 한다.	*/
void init();


int main(void)
{
    init();

    while (1) 
    {
		PORTB = LED;		// PORTB/C/D	: 특정 핀에 High/Low를 출력한다.
		_delay_ms(500);		// _delay_ms(x)	: xms 동안 MCU를 정지시킨다.
		PORTB = 0;
		_delay_ms(500);

		/*
		PORTB = LED;		// 이렇게 미리 자주 사용하는 것은 define하여 사용하면 가독성이 높아짐.
		_delay_ms(500);
		PORTB = !LED;
		_delay_ms(500);
		*/  

    }
}

/*				사용자 지정 함수				*/
/* 코드를 이쁘게 하기 위해 사용자 지정 함수		*/
/* 는 main문 아래 작성한다. (개인 취향)		*/
/* 컴파일러에게 이를 알려주기 위해 선언을 한다.*/
void init ()
{
	DDRB = 0b00000000;	// IO핀을 출력 모드로 설정한다.
//	DDRB = 0x00;	// IO핀을 입력 모드로 설정한다.
}



