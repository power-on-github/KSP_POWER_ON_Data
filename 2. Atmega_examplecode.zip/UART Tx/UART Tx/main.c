/*
 * UART Tx.c
 *
 * Created: 2018-04-25 오후 4:06:22
 * Author : right
 */ 

#define F_CPU 8000000UL
#include <avr/io.h>
#include <stdint.h>

#define baud	9600
#define ubrr	51

#define TX		2
#define SW1		0x02

#define OFF		0
#define	ON		1

uint8_t input = OFF;

void init();
void UART_init();
void uart_transmit();
void button_input();



int main(void)
{
	init();
	UART_init();
	
    while (1) 
    {
		// Button input
		button_input();

		// Transmitting
		uart_transmit();
    }
}


void init()
{
	DDRD = (1 << TX);
	DDRB = 0;

}

void UART_init()
{
	UBRRH = (ubrr >> 8);
	UBRRL = ubrr;
	UCSRB = (1 << RXEN) | (1 << TXEN) | (1 << RXCIE);
	UCSRC = (1 << URSEL) | (0 << USBS) | (3 << UCSZ0);

}

void uart_transmit()
{
	while(!(UCSRA & (1 << UDRE)));
	
	UDR = input;

}

void button_input()
{
	if (PINB & SW1)
	{
		input = ON;
	}
	else
	{
		input = OFF;
	}

}