/*
 * Final practice_tx.c
 *
 * Created: 2018-05-04 오후 12:40:21
 * Author : pata
 */ 

#define F_CPU 8000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdint.h>

#define OFF		0
#define ON		1
#define TX_BUS	0x02
#define BUTTON	0x01

void init();
void button();
void tx();

volatile uint8_t counter = 0;
volatile uint8_t sec = 0;
uint8_t flag = OFF;
uint8_t button_check =OFF;

ISR (TIMER0_OVF_vect)
{
	counter++;
	
	if (counter > 125)
	{
		sec++;
		counter = 0;
	}
}

int main(void)
{
    init();
	sei();
	
    while (1) 
    {
		button();
		
		if ((button_check == ON) && (sec > 4))
			tx();
			
    }
}

void init()
{
	DDRB = 0x02;	// PB0은 스위치 입력, PB1은 통신용
	
	TCCR0 = (1 << CS02);
	TIMSK = (1 << TOIE0);
}

void button()
{
	if (button_check == OFF)	// 한번 눌리면 값을 유지시킨다.
	{
		if (PINB & BUTTON)
		{
			button_check = ON;
			sec = 0;
			counter = 0;
		}
	}
		
}

void tx()
{
	PORTB = TX_BUS;
}