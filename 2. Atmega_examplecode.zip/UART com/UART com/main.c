/*
 * UART com.c
 *
 * Created: 2018-04-25 오후 9:04:06
 * Author : pata
 *
 *
 *      RESET   ==PC6----PC5==
 *      RX      ==PD0    PC4==
 *      TX      ==PD1    PC3==
 *              ==PD2    PC2==
                ==PD3    PC1==
                ==PD4    PC0==
 *      VCC     ==VCC    GND==   GND
 *      GND     ==GND   AREF==
 *              ==PB6   AVCC==
 *              ==PB7    PB5==
 *              ==PD5    PB4==
 *              ==PD6    PB3==
 *              ==PD7    PB2==
 *      LED     ==PB0----PB1==   SW1
 *
 *
 *      오늘의 코드:UART (Universal asynchronized Receive and Transmit) 
 *
 *      1. Atmega8에서 컴퓨터로 데이터를 전송한다.
 *
 *
 *
 */ 

#define F_CPU 8000000UL
#define ubrr   51

#include <avr/io.h>
#include <stdint.h>

#define baud   9600

void init();
void uart_tx(uint8_t a);
uint8_t uart_rx();

uint8_t recieve = 0;

int main(void)
{
   init();
   
    while (1) 
    {
      if (PINB & 0x02)
      {
         uart_tx(1);
      }
      
      recieve = uart_rx();
      
		if (recieve == 1)
			PORTB = 1;
		else
			PORTB = 0;

    }
}

void init()
{
   DDRD = 0x02;		// 0b00000010
   DDRB = 0x01;		// 0b00000001 

   UBRRH = (ubrr >> 8);
   UBRRL = ubrr;
   UCSRB = (1 << RXEN) | (1 << TXEN);
   UCSRC = (1 << URSEL) | (3 << UCSZ0);

}

void uart_tx(uint8_t input)
{
   while (!(UCSRA & (1 << UDRE)));
   UDR = input;

}

uint8_t uart_rx()
{
   while (!(UCSRA & (1 << RXC)));
   return UDR;

}