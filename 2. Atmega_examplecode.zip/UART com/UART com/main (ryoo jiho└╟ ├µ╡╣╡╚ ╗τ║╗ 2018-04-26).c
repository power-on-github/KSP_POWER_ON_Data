/*
 * UART com.c
 *
 * Created: 2018-04-25 오후 9:04:06
 * Author : pata
 */ 

#define F_CPU 8000000UL
#include <avr/io.h>
#include <stdint.h>

#define baud	9600
#define ubrr	51
#define TX		2

uint8_t input = 'A';

void init();
void UART_init();
void uart_transmit();


int main(void)
{
	init();
	UART_init();
	
    while (1) 
    {
		uart_transmit();
    }
}

void init()
{
	DDRD = (1 << TX);
	DDRB = 0;

}

void UART_init()
{
	UBRRH = (ubrr >> 8);
	UBRRL = ubrr;
	UCSRB = (1 << RXEN) | (1 << TXEN) | (1 << RXCIE);
	UCSRC = (1 << URSEL) | (0 << USBS) | (3 << UCSZ0);

}

void uart_transmit() 
{
	while(!(UCSRA & (1 << UDRE)));
	
	UDR = input;

}