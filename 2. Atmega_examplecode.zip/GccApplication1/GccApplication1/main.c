#include <avr/io.h>
#include <avr/interrupt.h>		// Interrupt를 위해 필요한 헤더 파일

volatile int counter = 0;
volatile int timer = 0;

// Interrupt Service Routine(ISR) :
// TIMER0 register가 overflow될 때마다 이 함수가 실행됨
ISR(TIMER0_OVF_vect)
{
	counter++;			//overflow 발생 때마다 counter 증가

	if(counter >= 31)
	{
		counter = 0;
		timer++;
	}
}

int main(void)
{
	DDRB = 0x01;		//  핀을 output mode로 설정
	TIMSK = 0x01;		// TIMER0 overflow interrupt 사용 설정
	TCCR0 = 0x05;		// prescalar를 1024로 설정

	sei();			// 사용 설정한 interrupt를 활성화

	while (1)
	{
		// timer 값에 따라  핀에 5V, 0V를 번갈아 가며 출력
		if(timer%2)
		PORTB = 0x01;
		else
		PORTB = 0x00;
	}
}


